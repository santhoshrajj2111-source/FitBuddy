# FitBuddy – Project Design Phase

## 1. Architecture Overview
Modular FastAPI architecture with four layers:

```
 Browser (HTML + Jinja2 templates)
        │  form POST / GET
        ▼
 FastAPI backend (routes.py, Pydantic validation)
        │                         │
        ▼                         ▼
 AI layer (Gemini APIs)     Database (SQLite + SQLAlchemy)
  • 1.5 Pro: plan/update     • users, plans (original + updated)
  • Flash: nutrition tip
```

| Layer | Technology | Responsibility |
|---|---|---|
| Frontend | HTML, CSS, Jinja2 | Input form, result display, admin panel |
| Backend | FastAPI + Uvicorn | Routing, form handling, orchestration |
| AI | Gemini 1.5 Pro / Flash | Workout generation, plan updates, tips |
| Data | SQLite + SQLAlchemy | Persist users and plans |

## 2. Module / File Design
| File | Purpose |
|---|---|
| `main.py` | App entry (`uvicorn main:app`) |
| `routes.py` | All routes and orchestration |
| `gemini_generator.py` | `generate_workout_gemini()` – Pro |
| `gemini_flash_generator.py` | `generate_nutrition_tip_with_flash()` – Flash |
| `updated_plan.py` | `update_workout_plan()` – Pro |
| `database.py` | `save_user`, `save_plan`, `update_plan`, `get_original_plan`, `get_user`, `get_all_users`, `get_all_plans` |
| `templates/` | `index.html`, `result.html`, `all_users.html` |
| `static/images/` | Background and assets |

## 3. Route Design
| Route | Method | Action |
|---|---|---|
| `/` | GET | Render `index.html` |
| `/generate-workout` | POST | Validate input → generate plan + tip → save user & plan → render `result.html` |
| `/submit-feedback` | POST | Fetch original plan → update via Gemini Pro → store → render `result.html` |
| `/view-all-users` | GET | Fetch all users/plans → render `all_users.html` |
| `/docs` | GET | FastAPI Swagger docs |

## 4. Data Flow
**Plan generation:** User form → `/generate-workout` → Gemini Pro (plan) + Gemini Flash (tip) → DB save → `result.html`.
**Feedback:** Feedback form (user ID + text) → `/submit-feedback` → DB lookup → Gemini Pro (original + feedback) → DB update → `result.html`.
**Admin:** `/view-all-users` → DB read → table in `all_users.html`.

## 5. Database Design
| Entity | Fields |
|---|---|
| User | id, name, age, weight, goal, intensity |
| Plan | user reference, original plan, updated plan |

Original and updated plans are separate fields so both versions are preserved.

## 6. AI / Prompt Design
| Function | Model | Input | Expected output |
|---|---|---|---|
| Workout generation | Gemini 1.5 Pro | goal, intensity (plus user details) | 7 days: warm-up (5–10 min), main workout (exercises, sets, reps), cooldown/recovery tip |
| Nutrition tip | Gemini Flash | goal | Short practical tip (hydration, protein, recovery) |
| Plan update | Gemini 1.5 Pro | original plan + feedback | Revised plan |

## 7. UI Design
- **Home (`index.html`):** centered form, gym-themed background, Roboto font, "Generate Plan" button.
- **Result (`result.html`):** user summary, `<pre>`-formatted plan, nutrition tip, feedback form.
- **Admin (`all_users.html`):** table of users with original and updated plans, delete option.
- Styling: embedded CSS, Flexbox centering, media queries, hover buttons, rounded/shadowed blocks, dark background.

## 8. Design Decisions
- Two models split by task: quality (Pro) vs. speed (Flash).
- Server-side rendering with Jinja2 for simplicity.
- SQLite for zero-setup local persistence.
- Secrets via environment variables.
