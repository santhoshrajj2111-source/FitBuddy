# FitBuddy – Project Development Phase

## 1. Environment Setup (Activity 1.3)
```bash
python -m venv fitbuddy-env
fitbuddy-env\Scripts\activate        # Windows (source venv/bin/activate on Linux/Mac)
pip install fastapi uvicorn jinja2 sqlalchemy python-multipart google-generativeai
uvicorn app.main:app --reload
```
Project folders: `/app` (Python), `/templates` (HTML), `/static/images` (assets).
Store the key as `GOOGLE_API_KEY` in the environment or a `.env` file (loaded with `python-dotenv`).

## 2. Core Functionality (Milestone 2)
| Function | File | Model | Description |
|---|---|---|---|
| `generate_workout_gemini()` | `gemini_generator.py` | Gemini 1.5 Pro | 7-day plan from goal and intensity: warm-up, main workout (sets/reps), cooldown/recovery |
| `generate_nutrition_tip_with_flash()` | `gemini_flash_generator.py` | Gemini Flash | Concise nutrition/recovery tip |
| `update_workout_plan()` | `updated_plan.py` | Gemini 1.5 Pro | Revises original plan using user feedback |
| `save_user()`, `save_plan()`, `update_plan()`, `get_original_plan()`, `get_user()`, `get_all_users()`, `get_all_plans()` | `database.py` | SQLAlchemy / SQLite | Persist and fetch users and plans |

Input handling: `Form(...)` parameters; Pydantic `UserInput` and `FeedbackRequest` for validation.

## 3. Routes (Milestone 3 – `routes.py`)
| Route | Logic |
|---|---|
| `/` | Return `index.html` |
| `/generate-workout` | Build `UserInput` → `generate_workout_gemini()` → `generate_nutrition_tip_with_flash()` → `save_user()` / `save_plan()` → `result.html` |
| `/submit-feedback` | Read feedback + user ID → `get_original_plan()` → `update_workout_plan()` → `update_plan()` → `result.html` |
| `/view-all-users` | `get_all_users()` + `get_all_plans()` → `all_users.html` |

## 4. Frontend (Milestone 4)
Template rendering setup:
```python
from fastapi.templating import Jinja2Templates
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, "templates")
templates = Jinja2Templates(directory=TEMPLATE_DIR)
```
| Template | Content |
|---|---|
| `index.html` | Form (username, user_id, age, weight, goal, intensity) posting to `/generate-workout` |
| `result.html` | `{{ username }}`, `{{ goal }}`, `{{ intensity }}`, `{{ workout_plan }}`, `{{ nutrition_tip }}`; feedback form posting to `/submit-feedback` |
| `all_users.html` | `{% for user in users %}` loop showing details, original and updated plans, delete option |

Styling: embedded CSS, Roboto font, gym background, Flexbox, media queries, hover effects.

## 5. Deployment Preparation (Milestone 5)
1. Create and activate virtual environment.
2. `pip install -r requirements.txt`.
3. Set `GOOGLE_API_KEY`.
4. Run `uvicorn main:app --reload` and open `http://127.0.0.1:8000` (docs at `/docs`).

## 6. Development Notes
- Plans are shown in `<pre>` blocks to preserve AI formatting.
- Original and updated plans are stored separately.
- Note: the report shows both `app.main:app` and `main:app` as the run command; use whichever matches your folder layout.
