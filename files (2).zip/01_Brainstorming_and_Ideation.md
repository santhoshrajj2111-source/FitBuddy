# FitBuddy – Brainstorming & Ideation Phase

## 1. Project Title
**FitBuddy – AI Fitness Plan Generator using Gemini Models**

## 2. Problem Statement
Most people struggle to build structured, goal-specific workout routines. Generic plans ignore age, weight, goal and preferred intensity, and professional trainers are costly and hard to scale. There is no quick way to revise a plan as preferences or progress change.

## 3. Idea Summary
FitBuddy is a web application that uses Google Gemini models to generate:
- a personalized **7-day workout plan** from the user's name, age, weight, goal (weight loss, muscle gain, general wellness) and intensity (low / medium / high);
- a concise **nutrition or recovery tip** matched to the goal;
- an **updated plan** when the user submits feedback (e.g. "more cardio", "add rest days");
- an **admin/coach dashboard** listing all users with original and updated plans.

## 4. Target Users
| Segment | Need |
|---|---|
| Beginners / general users | Simple, structured routine without hiring a trainer |
| Goal-driven users (weight loss, muscle gain) | Plans and tips aligned with their goal |
| Coaches / trainers | One view to monitor many clients and plan changes |

## 5. Brainstormed Scenarios
1. **Personalized plan** – user enters details, receives a day-by-day 7-day plan.
2. **Feedback loop** – user requests changes; AI regenerates the plan.
3. **Nutrition/recovery tip** – short goal-based advice shown with the plan.
4. **Admin oversight** – coach views all users and compares original vs. updated plans.

## 6. Model Options Considered
| Option | Observation |
|---|---|
| Hugging Face T5 / BART | Text generation possible, but needs hosting/GPU and heavy prompting for structured plans |
| DistilBERT | Considered for intent classification; not needed for generation |
| Bloom | General-purpose; limited structure and extra setup |
| **Gemini 1.5 Pro** | Structured, context-aware 7-day plans and plan updates |
| **Gemini Flash** | Fast, lightweight nutrition tips |

**Decision:** Gemini 1.5 Pro for workouts/updates, Gemini Flash for tips (API-based, easy FastAPI integration, minimal prompt tuning, scalable).

## 7. Technology Ideas Shortlist
FastAPI (backend), Jinja2 + HTML/CSS (frontend), SQLite + SQLAlchemy (storage), Uvicorn (server), Gemini API (AI layer).

## 8. Unique Value Proposition
- AI-generated, goal-specific plans in seconds
- Built-in **feedback-driven refinement**
- Both original and updated plans preserved
- Coach-friendly admin view
- Dual-model design balancing quality (Pro) and speed (Flash)

## 9. Risks & Mitigations (brainstormed)
| Risk | Mitigation idea |
|---|---|
| Inconsistent AI output format | Structured prompts; display in `<pre>` blocks |
| API key exposure | Store in environment variables / `.env` |
| Unsafe or unsuitable advice | Keep tips general; show a "consult a professional" note |
| API latency | Use Flash for quick tasks |

## 10. Future Ideas (parking lot)
Cloud deployment, user login, progress tracking, meal plans, wearable integration, plan export to PDF.
