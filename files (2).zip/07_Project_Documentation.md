# FitBuddy – Project Documentation Phase

## 1. Overview
FitBuddy is a FastAPI web app that uses Gemini 1.5 Pro and Gemini Flash to generate personalized 7-day workout plans, nutrition/recovery tips, and feedback-based plan updates, with SQLite storage and an admin dashboard.

## 2. Features
- Personalized 7-day workout plan (warm-up, main workout, cooldown)
- Goal-based nutrition/recovery tip
- Feedback-driven plan updating
- Storage of original and updated plans
- Admin view of all users and plans
- Interactive API docs (`/docs`)

## 3. Technology Stack
Python · FastAPI · Uvicorn · Jinja2 · HTML/CSS · SQLAlchemy · SQLite · Google Generative AI (Gemini 1.5 Pro, Flash)

## 4. Project Structure
```
app/ or root
 ├─ main.py
 ├─ routes.py
 ├─ gemini_generator.py
 ├─ gemini_flash_generator.py
 ├─ updated_plan.py
 ├─ database.py
 ├─ requirements.txt
templates/  index.html  result.html  all_users.html
static/images/
```

## 5. Installation & Setup
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```
Set the key:
```
GOOGLE_API_KEY=your_gemini_api_key_here
```
Run:
```bash
uvicorn main:app --reload
```
Open `http://127.0.0.1:8000` (API docs: `/docs`).

## 6. User Guide
1. **Generate a plan:** enter name, user ID, age, weight, goal and intensity → *Generate Plan*.
2. **Read results:** view your summary, 7-day plan and nutrition tip.
3. **Refine:** enter your user ID and feedback (e.g. "add yoga") on the feedback form; the updated plan is shown with a confirmation.
4. **Admin:** open `/view-all-users` to review users, original/updated plans, and delete records.

## 7. API / Route Reference
| Route | Method | Purpose |
|---|---|---|
| `/` | GET | Home form |
| `/generate-workout` | POST | Create plan + tip |
| `/submit-feedback` | POST | Update plan from feedback |
| `/view-all-users` | GET | Admin dashboard |
| `/docs` | GET | Swagger UI |

## 8. Function Reference
| Function | File | Purpose |
|---|---|---|
| `generate_workout_gemini()` | gemini_generator.py | 7-day plan via Gemini 1.5 Pro |
| `generate_nutrition_tip_with_flash()` | gemini_flash_generator.py | Tip via Gemini Flash |
| `update_workout_plan()` | updated_plan.py | Revise plan from feedback |
| `save_user()`, `save_plan()`, `update_plan()`, `get_original_plan()`, `get_user()` | database.py | Persistence |

## 9. Model Selection Summary
Hugging Face models (T5, BART, DistilBERT, Bloom) needed hosting/GPU and heavy prompting. Gemini was chosen for API-based integration, structured output, accuracy with little tuning, and speed.

## 10. Security & Safety Notes
- Keep the API key out of source control.
- Plans and tips are general guidance, not medical advice; users should consult a professional for health conditions.

## 11. Known Limitations / Future Work
No authentication; local deployment only; no progress tracking. Planned: cloud deployment, login, meal plans, analytics, PDF export.

## 12. Conclusion
FitBuddy demonstrates practical integration of generative AI with a lightweight web stack to deliver adaptive, personalized fitness planning for individuals and coaches.
