# FitBuddy – Requirement Analysis Phase

## 1. Purpose
Define what FitBuddy must do, for whom, and under what constraints.

## 2. Stakeholders
- **End users** – request plans, tips and updates.
- **Admin / coach** – monitors users and plans.
- **Developers** – build and maintain the system.

## 3. Functional Requirements
| ID | Requirement |
|---|---|
| FR-1 | Home page form captures username, user ID, age, weight, goal and intensity (low/medium/high). |
| FR-2 | System generates a structured 7-day workout plan (warm-up, main workout with sets/reps, cooldown/recovery) via Gemini 1.5 Pro. |
| FR-3 | System generates a concise nutrition/recovery tip for the selected goal via Gemini Flash. |
| FR-4 | Results page shows user summary, plan and tip. |
| FR-5 | User can submit feedback (with user ID) to update the existing plan using Gemini 1.5 Pro. |
| FR-6 | System stores user details, original plan and updated plan separately in SQLite. |
| FR-7 | Admin page (`/view-all-users`) lists all users with original and updated plans. |
| FR-8 | Admin page allows deleting users (as described for `all_users.html`). |
| FR-9 | Confirmation message shown after a plan is updated. |
| FR-10 | Interactive API docs available at `/docs`. |

## 4. Non-Functional Requirements
| ID | Requirement |
|---|---|
| NFR-1 | Usability – clean, gym-themed, minimal-navigation UI. |
| NFR-2 | Responsiveness – Flexbox layout and media queries for mobile. |
| NFR-3 | Performance – near real-time AI responses; Flash for quick calls. |
| NFR-4 | Security – Gemini API key kept in environment variables, not code. |
| NFR-5 | Maintainability – modular files (routes, generators, database). |
| NFR-6 | Reliability – data persisted so plans remain accessible. |
| NFR-7 | Scalability – design suited to later cloud deployment. |

## 5. Data Requirements
**User:** ID, name, age, weight, goal, intensity.
**Plan:** original plan text, updated plan text (separate field), linked to user.
**Input validation:** Pydantic schemas `UserInput` and `FeedbackRequest`.

## 6. Technical / Environment Requirements
| Area | Requirement |
|---|---|
| Language | Python |
| Backend | FastAPI, Uvicorn |
| AI | Google Generative AI SDK (`google-generativeai`), Gemini 1.5 Pro & Flash |
| Database | SQLite via SQLAlchemy |
| Frontend | HTML, CSS, Jinja2, `python-multipart` for forms |
| Tools | pip/virtualenv, Git, `python-dotenv` |
| Credentials | `GOOGLE_API_KEY` |

## 7. Prerequisite Skills
FastAPI, Gemini API, HTML/CSS/Jinja2, Python, Git, SQLAlchemy/SQLite, virtual environments, Uvicorn.

## 8. Use-Case Summary
| Use case | Actor | Outcome |
|---|---|---|
| Generate plan | User | 7-day plan + tip |
| Submit feedback | User | Updated plan |
| View all users | Admin | Original vs. updated plans |

## 9. Assumptions & Constraints
- Runs locally first (127.0.0.1:8000); cloud deployment is future work.
- Requires internet access and a valid Gemini API key.
- Plans are general guidance, not medical advice.
- No user authentication specified in the current scope.

## 10. Acceptance Criteria
- Valid form submission returns a plan and tip.
- Feedback changes the stored updated plan while the original is retained.
- Admin page shows all users and both plan versions.
- App starts with `uvicorn` and loads at `/` and `/docs`.
