# FitBuddy – Project Planning Phase

## 1. Objective
Plan the work to deliver FitBuddy locally, organised by the five milestones in the project report.

## 2. Work Breakdown (Milestones & Activities)
| Milestone | Activities |
|---|---|
| **M1 – Model selection & architecture** | 1.1 Research and select generative AI model; 1.2 Define application architecture; 1.3 Set up development environment |
| **M2 – Core functionalities** | 2.1 Develop core functions (workout, tip, update, storage, admin view); 2.2 Implement FastAPI backend for routing and input processing |
| **M3 – routes.py** | 3.1 Write main application logic and route handlers |
| **M4 – Frontend** | 4.1 Design and develop UI; 4.2 Create dynamic Jinja2 templates |
| **M5 – Deployment** | 5.1 Prepare for local deployment; 5.2 Test and verify local deployment |

## 3. Suggested Timeline (indicative – adjust to your schedule)
| Week | Focus | Deliverable |
|---|---|---|
| 1 | M1 | Model decision, architecture, working environment |
| 2 | M2 | Generator modules, DB functions |
| 3 | M3 | Complete `routes.py` |
| 4 | M4 | Three templates with styling |
| 5 | M5 | Verified local run, documentation, demo |

## 4. Task Allocation (template)
| Task | Owner | Status |
|---|---|---|
| Model research & selection | _TBD_ | |
| Backend & routes | _TBD_ | |
| AI functions | _TBD_ | |
| Database | _TBD_ | |
| Frontend | _TBD_ | |
| Testing & docs | _TBD_ | |

## 5. Resources
- Software: Python, pip/virtualenv, Git, VS Code, browser.
- Libraries: fastapi, uvicorn, jinja2, sqlalchemy, python-multipart, google-generativeai, python-dotenv.
- Services: Gemini API key (`GOOGLE_API_KEY`).

## 6. Risk Plan
| Risk | Impact | Mitigation |
|---|---|---|
| API key leak | High | Env variables / `.env`, keep out of Git |
| Gemini quota or latency | Medium | Use Flash for light tasks; handle errors |
| Unstructured AI output | Medium | Refine prompts; render in `<pre>` |
| Dependency mismatch | Low | `requirements.txt` + virtualenv |
| Scope creep | Medium | Defer login, cloud hosting to future work |

## 7. Milestone Exit Criteria
| Milestone | Done when |
|---|---|
| M1 | Models chosen, environment runs a hello-world FastAPI app |
| M2 | Each AI/DB function returns correct output standalone |
| M3 | All four routes respond correctly |
| M4 | Pages render dynamic data and are responsive |
| M5 | App runs at `127.0.0.1:8000` and `/docs` |

## 8. Communication & Version Control
Use Git for all code; commit per activity; review at each milestone end.

## 9. Future Roadmap
Cloud deployment, authentication, progress tracking, meal plans, PDF export.
