# FitBuddy – Project Testing Phase

## 1. Objective
Verify that all features work correctly on a local deployment and meet the requirements.

## 2. Test Environment
Local machine, Python virtualenv, Uvicorn at `http://127.0.0.1:8000`, valid `GOOGLE_API_KEY`, SQLite database, modern browser.

## 3. Test Types
Functional, integration (routes ↔ Gemini ↔ DB), UI/responsiveness, API (via `/docs`), and basic error/negative testing.

## 4. Test Cases
| ID | Feature | Steps | Expected result |
|---|---|---|---|
| TC-01 | Home page | Open `/` | Form with name, user ID, age, weight, goal, intensity loads |
| TC-02 | Generate plan (weight loss, medium) | Fill form → Generate Plan | Result page shows user summary, 7-day plan, nutrition tip |
| TC-03 | Generate plan (muscle gain, high) | Same as above | Plan matches goal/intensity; tip relevant |
| TC-04 | Plan structure | Inspect output | Each day has warm-up, main workout (sets/reps), cooldown/recovery |
| TC-05 | Nutrition tip | Check below plan | Concise, goal-relevant tip |
| TC-06 | Data storage | Submit form, check admin page | User and original plan stored |
| TC-07 | Feedback update | Enter user ID + "more cardio" | Updated plan reflects feedback; confirmation shown |
| TC-08 | Version retention | After TC-07, view admin page | Original and updated plans both visible |
| TC-09 | Feedback with unknown user ID | Submit invalid ID | Graceful error, no crash |
| TC-10 | Missing/invalid fields | Submit blank or non-numeric age/weight | Validation prevents bad input |
| TC-11 | Admin view | Open `/view-all-users` | All users listed with details and plans |
| TC-12 | Delete user | Use delete in admin panel | User removed from list |
| TC-13 | API docs | Open `/docs` | Swagger UI lists endpoints |
| TC-14 | Responsiveness | Resize / mobile view | Layout adapts, content readable |
| TC-15 | Missing API key | Run without `GOOGLE_API_KEY` | Clear error, app does not expose secrets |
| TC-16 | AI failure/timeout | Simulate API error | User-friendly error message |

## 5. Results Log (to complete during testing)
| ID | Status (Pass/Fail) | Tester | Date | Remarks |
|---|---|---|---|---|
| TC-01 | | | | |
| … | | | | |

## 6. Defect Tracking Template
| Bug ID | Description | Severity | Steps to reproduce | Status |
|---|---|---|---|---|

## 7. Exit Criteria
- All high-priority cases (TC-01 to TC-08, TC-11) pass.
- No critical defects open.
- App runs from a clean virtualenv using `requirements.txt`.

## 8. Observations from the Report
Local deployment was verified by exploring the home page, personalized plan page, nutrition tip, feedback page (with update confirmation) and view-all-users page.
